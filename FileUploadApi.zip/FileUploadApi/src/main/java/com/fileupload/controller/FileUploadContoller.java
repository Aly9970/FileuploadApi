package com.fileupload.controller;

import java.io.IOException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;


import com.fileupload.service.StorageService;

@RestController
@RequestMapping("/image")
public class FileUploadContoller {
	@Autowired
	private StorageService service;
	@PostMapping
public ResponseEntity<?> uploadImg(@RequestParam("image") MultipartFile file) throws IOException{
	String UploadImg=service.uploadImg(file);
	return ResponseEntity.status(HttpStatus.OK)
			.body(UploadImg);
}
	  @GetMapping("/{filename}")
	    public ResponseEntity<?> DownaloadFile(@PathVariable String filename) {
	        byte[] fileData = service.downloadImage(filename);

	        // Determine the file extension
	        String fileExtension = getFileExtension(filename);

	        // Set appropriate media type based on file extension
	        MediaType mediaType = getMediaTypeForExtension(fileExtension);

	        if (mediaType == null) {
	            // Unsupported file type
	            return ResponseEntity.status(HttpStatus.UNSUPPORTED_MEDIA_TYPE).body("Unsupported file type");
	        }

	        return ResponseEntity.status(HttpStatus.OK)
	                .contentType(mediaType)
	                .body(fileData);
	    }

	    private String getFileExtension(String filename) {
	        return filename.substring(filename.lastIndexOf(".") + 1);
	    }

	    private MediaType getMediaTypeForExtension(String extension) {
	        switch (extension.toLowerCase()) {
	            case "jpg":
	            case "jpeg":
	            case "png":
	            case "gif":
	                return MediaType.IMAGE_JPEG; // Assuming all image types are treated as JPEG
	            case "xlsx":
	                return MediaType.APPLICATION_OCTET_STREAM;
	            case "pdf":
	                return MediaType.APPLICATION_PDF;
	            default:
	                return null; // Unsupported file type
	        }
	    }
}
