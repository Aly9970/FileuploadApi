package com.fileupload.respository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.fileupload.entity.Imagedata;

@Repository
public interface StorageRespository extends JpaRepository<Imagedata, Long>{
public Optional<Imagedata> findByname(String name);
}
