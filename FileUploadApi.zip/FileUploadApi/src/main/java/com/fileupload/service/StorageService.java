package com.fileupload.service;

import java.io.IOException;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.fileupload.entity.Imagedata;
import com.fileupload.respository.StorageRespository;
import com.fileupload.utils.ImageUtils;

@Service
public class StorageService {

	@Autowired
	private StorageRespository respo;
	public String uploadImg(MultipartFile file) throws IOException {
		Imagedata imgData = respo.save(Imagedata.builder().name(file.getOriginalFilename()).
				type(file.getContentType()).imageData(ImageUtils.compressImage(file.getBytes())).build());
		if(imgData!=null) {
			return"File Uploaded Sucessfully"+file.getOriginalFilename();
		}
	
	return "Not Uploaded Its Succesfully";
	}
	public byte[] downloadImage(String filename) {
		Optional<Imagedata> dbImg = respo.findByname(filename);
		byte[] img = ImageUtils.decompressImage(dbImg.get().getImageData());
		return img;
	}
}
